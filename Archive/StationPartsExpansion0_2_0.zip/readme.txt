==============================
STATION PARTS EXPANSION v0.2.0
==============================

This is a pack for expanding the line of stockalike parts useful for space stations and surface bases.

============
INSTALLATION
============

To install, place the GameData folder inside your Kerbal Space Program folder. If asked to overwrite files, do so. 

Please note that this pack is VERY sensitive to install location. Do not move or rename the StationPartsExpansion folder or any of the contents

As this pack bundles Raster Prop Monitor v0.18, please check to make sure you have a newer or concurrent version of the following files:
� GameData\JSI\RasterPropMonitor\Plugins\RasterPropMonitor.dll
� GameData\JSI\RasterPropMonitor\Plugins\MechJebRPM.dll

=========
LICENSING
=========

The contents of this pack are distributed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

You are free to share and adapt the materials only for non-commercial purposes and when providing appropriate attribution. Any derivatives must be distributed under the same license. 

Raster Prop Monitor (v0.18) is distributed under its own licence (GPL). Please find source code and more details at https://github.com/Mihara/RasterPropMonitor/

Elements of the RPM screens used in this pack are courtesy of alexustas and are distributed under CC-BY-NC-SA 3.0 as per their license. 