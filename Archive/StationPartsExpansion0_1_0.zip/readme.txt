==============================
STATION PARTS EXPANSION v0.1.0
==============================

This is a pack for expanding the line of stockalike parts useful for space stations and surface bases.

============
INSTALLATION
============

To install, place the GameData folder inside your Kerbal Space Program folder. If asked to overwrite files, do so. 




=========
LICENSING
=========

The contents of this pack are distributed a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License (http://creativecommons.org/licenses/by-nc-sa/3.0/deed.en_GB).

You are free to share and adapt the materials only for non-commercial purposes and when provide appropriate attribution. Any derivatives must be distributed under the same license. 